
# Security Policy

Report vulnerabilities privately. Do not open public issues for security flaws.

Scope includes injection detection, tool enforcement, rate limiting, secret scanning, and dashboard exposure.
