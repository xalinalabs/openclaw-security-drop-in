
# OpenClaw Security

Lightweight security hardening layer for OpenClaw AI agents.

## Features

- Prompt injection detection
- Tool allowlists
- Rate limiting
- Secret leakage scanning
- Audit logging
- Live dashboard
- CLI project scanner

## Installation

pip install openclaw-security

## Quick Start

from openclaw_security import SecurityAgent
from openclaw_security.middleware import SecurityMiddleware

security = SecurityAgent()
middleware = SecurityMiddleware(security)

agent.run = middleware.wrap_agent("trading_agent", agent.run)

## Run Dashboard

openclaw-sec-dashboard
