
# Contributing

Keep changes minimal and security-focused.

Avoid heavy dependencies.

Update documentation when behavior changes.
